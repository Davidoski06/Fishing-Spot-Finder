<?php
require_once '.env.php';

//--Leggo i parametri inviati dal form
$provincia = $_GET['provincia'] ?? '';
$fish = $_GET['fish'] ?? '';

//--Leggo il file JSON con gli spot
$spots = json_decode(file_get_contents('data/spots.json'), true);
$risultati = [];

$latTot = 0;
$lonTot = 0;
$conteggio = 0;

//--Cerco gli spot che corrispondono ai filtri
foreach ($spots as $spot) {
  $provOk = !$provincia || strtolower($spot['provincia']) === strtolower($provincia);
  $fishOk = true;

  if ($fish) {
    $fishOk = false;
    foreach ($spot['fish'] as $f) {
      if (stripos($f, $fish) !== false) {
        $fishOk = true;
        break;
      }
    }
  }

  if ($provOk && $fishOk) {
    $meteo = prendiMeteo($spot['lat'], $spot['lon']);
    $spot['weather'] = $meteo;
    $risultati[] = $spot;

    $latTot += $spot['lat'];
    $lonTot += $spot['lon'];
    $conteggio++;
  }
}

//--Se ci sono risultati, calcolo il centro per la mappa
if ($conteggio > 0) {
  $center = [
    'lat' => $latTot / $conteggio,
    'lon' => $lonTot / $conteggio
  ];
} else {
  $center = ['lat' => 42.5, 'lon' => 12.5]; // centro Italia
}

//--Funzione per prendere il meteo da OpenWeather
function prendiMeteo($lat, $lon) {
  $key = OPENWEATHER_API_KEY;
  $url = "https://api.openweathermap.org/data/2.5/weather?lat={$lat}&lon={$lon}&appid={$key}&units=metric&lang=it";
  $res = file_get_contents($url);
  $data = json_decode($res, true);

  return [
    'temperatura' => $data['main']['temp'],
    'condizioni' => $data['weather'][0]['description'],
    'vento' => $data['wind']['speed']
  ];
}

//--Rispondo al front-end con i dati
header('Content-Type: application/json');
echo json_encode([
  'spots' => $risultati,
  'center' => $center
]);
?>
